package com.example.gazipasa_municipality;

import static com.example.gazipasa_municipality.R.id.imageSwitcher1;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    private Button btn1, btn2, btn3, btn4, btn5, btn6;
    private String wpPhoheNumber = "+90 533 195 56 64";
    private BottomNavigationView bottomNavigationView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);

        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        loadFragment(new Fragment());
    }

    public void btnClick(View v) {
        switch (v.getId()) {
            case R.id.btn1:
               Intent haberbulteni= new Intent(MainActivity.this,HaberBulteni.class);
               startActivity(haberbulteni);
                break;
            case R.id.btn2:
                String phoneNumberWithOutCountryCode = wpPhoheNumber.trim();
                phoneNumberWithOutCountryCode = wpPhoheNumber.substring(3);
                if (appInstalledOrNot("com.whatsapp")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://api.whatsapp.com/send?phone=" + "+90" + phoneNumberWithOutCountryCode));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Whatsapp uygulaması telefonunuzda yüklü değil", Toast.LENGTH_SHORT); //Alert ile değiştirelecek.
                }
                break;
            case R.id.btn3:
                Intent HalkMasaDirection = new Intent(MainActivity.this, HalkMasa.class);
                startActivity(HalkMasaDirection);
                break;
            case R.id.btn4:
                break;
            case R.id.btn5:
                break;
            case R.id.btn6:
                Intent iletişimHattı = new Intent(MainActivity.this, HalkMasa2.class);
                startActivity(iletişimHattı);
                break;
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()) {
            case R.id.Bildirimler:
                System.out.println("Bildirimler.");
                break;
            case R.id.E_Belediye:
                Intent OnlinePayment = new Intent(MainActivity.this, OnlinePayment.class);
                startActivity(OnlinePayment);
                break;
            case R.id.Ayarlar:
                System.out.println("E-Belediye.");
                break;

        }
        if (fragment != null) {
            loadFragment(fragment);
        }


        return true;
    }

    public boolean appInstalledOrNot(String url) {
        PackageManager packageManager = getPackageManager();
        boolean app_instaled;
        try {
            packageManager.getPackageInfo(url, packageManager.GET_ACTIVITIES);
            app_instaled = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_instaled = false;
        }
        return app_instaled;
    }

    public void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.relativelayout, fragment).commit();

    }
}