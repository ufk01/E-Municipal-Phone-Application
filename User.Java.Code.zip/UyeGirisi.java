package com.example.gazipasa_municipality;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class UyeGirisi extends AppCompatActivity {
    private EditText UserInfo2, UserPassword;
    private Button Giris2, ShowPasswordBtn;
    private Connection connect;
    private String ConnectionResult = "";
    private static int counter = 0, namecounter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_uye_girisi);
        UserInfo2 = (EditText) findViewById(R.id.UserInfo2);
        UserPassword = (EditText) findViewById(R.id.UserPassword);
        Giris2 = (Button) findViewById(R.id.Giris2);
        ShowPasswordBtn = (Button) findViewById(R.id.ShowPasswordBtn);
        Giris2.setText("Giriş");

    }

    public void getSqlTxt(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(UyeGirisi.this);
        String id = UserInfo2.getText().toString();
        String password = UserPassword.getText().toString();
        if (id.isEmpty() || password.isEmpty()) {
            builder.setTitle("Boş işlem yapılamaz");
            builder.setPositiveButton("Kapat", (DialogInterface.OnClickListener) (dialog, which) -> {
                dialog.cancel();
            });
            builder.show();
            UserInfo2.setText("");
            UserPassword.setText("");
        } else {
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                connect = connectionHelper.UygeGirisconnectionclass();
                if (connect != null) {
                    String query = "select \"TC_Kimlik\",\"Sicil_No\",\"Vergi_No\",\"Sifre\" from Sheet1$ ";
                    Statement st = connect.createStatement();
                    ResultSet rs = st.executeQuery(query);
                    while (rs.next()) {

                        if (rs.getString(1).trim().equals(id.trim()) || rs.getString(2).trim().equals(id.trim()) || rs.getString(3).trim().equals(id.trim())) {
                            namecounter++;
                            if (rs.getString(4).trim().equals(password.trim())) {
                                counter++;
                                break;
                            }
                        }

                    }

                    if (namecounter == 0) {
                        builder.setTitle("Bilgilerinizi tekrar kontrol ediniz.");
                        builder.setPositiveButton("Kapat", (DialogInterface.OnClickListener) (dialog, which) -> {
                            dialog.cancel();
                        });
                        builder.show();
                        counter = 0;
                    } else if (counter == 0 && namecounter != 0) {
                        builder.setTitle("Şifrenizi yanlış girdiniz.");
                        builder.setPositiveButton("Kapat", (DialogInterface.OnClickListener) (dialog, which) -> {
                            dialog.cancel();
                        });
                        builder.show();
                        UserPassword.setText("");
                        namecounter = 0;
                    } else {
                        counter = 0;
                        UserInfo2.setText("");
                        UserPassword.setText("");
                        CallOdemeYapma();
                    }
                } else {
                    ConnectionResult = "Bağlantıyı kontrol ediniz";
                    System.out.println(ConnectionResult);
                }
            } catch (Exception e) {
                Log.e("Sistemde sorun var!", e.getMessage());
            }
        }
    }

    public void CallOdemeYapma() {
        Intent odemeyapma = new Intent(UyeGirisi.this, OdemeYapma.class);
        startActivity(odemeyapma);
    }

    public void ShowPassword(View v) {

        if (ShowPasswordBtn.getContentDescription().toString().equals("Show")) {
            UserPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            ShowPasswordBtn.setBackgroundResource(R.drawable.pictogrammers_material_eye_outline_512);
            ShowPasswordBtn.setContentDescription("Off");
        } else if (ShowPasswordBtn.getContentDescription().toString().equals("Off")) {
            UserPassword.setTransformationMethod(new PasswordTransformationMethod());
            ShowPasswordBtn.setBackgroundResource(R.drawable.pictogrammers_material_eye_off_outline_512);
            ShowPasswordBtn.setContentDescription("Show");


        }
    }
}