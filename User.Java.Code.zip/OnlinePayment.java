package com.example.gazipasa_municipality;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OnlinePayment extends AppCompatActivity {
    private TextView txt1, txt2;
    private Button SMSbtn, UyeGirisbtn;
    private EditText UserInfo, UserPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_online_payment);
        txt1 = (TextView) findViewById(R.id.GirisTxt);
        txt2 = (TextView) findViewById(R.id.MainTxt);
        txt1.setText("Giriş Yap");
        txt2.setText(" \"Yasa gereği belediyemizdeki işlemlerde gerçek kişiler için Türkiye Cumhuriyeti Kimlik Numarası (T.C. Kimlik No.)," +
                " işyerleri için Vergi Kimlik Numarası (Vergi No.) ile işlem yapılması zorunludur.\"");
        SMSbtn = (Button) findViewById(R.id.SMSbtn);
        UyeGirisbtn = (Button) findViewById(R.id.UyeGirisbtn);
        SMSbtn.setText("SMS ile giriş");
        UyeGirisbtn.setText("Üye Girişi");
    }

    public void btnClick(View v) {
        switch (v.getId()) {
            case R.id.SMSbtn:
                Intent SmsGiris = new Intent(OnlinePayment.this, SMSGiris.class);
                startActivity(SmsGiris);
                break;
            case R.id.UyeGirisbtn:
                Intent UyeGirisi = new Intent(OnlinePayment.this, UyeGirisi.class);
                startActivity(UyeGirisi);
                break;
        }

    }

}