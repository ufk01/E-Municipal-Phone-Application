package com.example.gazipasa_municipality;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class HaberBulteni extends AppCompatActivity {
    CardView BTN1, BTN2, BTN3, BTN4, BTN5, BTN6, BTN7, BTN8;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_haber_bulteni);
        BTN1 = (CardView) findViewById(R.id.BTN1);
        BTN2 = (CardView) findViewById(R.id.BTN2);
        BTN3 = (CardView) findViewById(R.id.BTN3);
        BTN4 = (CardView) findViewById(R.id.BTN4);
        BTN5 = (CardView) findViewById(R.id.BTN5);
        BTN6 = (CardView) findViewById(R.id.BTN6);
        BTN7 = (CardView) findViewById(R.id.BTN7);
        BTN8 = (CardView) findViewById(R.id.BTN8);


    }

    public void OnCLick(View v) {
        switch (v.getId()) {
            case R.id.BTN1:
                Intent intent1 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent1);
                break;
            case R.id.BTN2:
                Intent intent2 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent2);
                break;
            case R.id.BTN3:
                Intent intent3 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent3);
                break;
            case R.id.BTN4:
                Intent intent4 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent4);
                break;
            case R.id.BTN5:
                Intent intent5 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent5);
                break;
            case R.id.BTN6:
                Intent intent6 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent6);
                break;
            case R.id.BTN7:
                Intent intent7 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent7);
                break;
            case R.id.BTN8:
                Intent intent8 = new Intent(HaberBulteni.this, MainActivity.class);
                startActivity(intent8);
                break;
        }
    }

}