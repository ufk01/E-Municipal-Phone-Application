package com.example.gazipasa_municipality;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.example.gazipasa_municipality.databinding.ActivityMainBinding;
import com.example.gazipasa_municipality.databinding.ActivitySmsconfgBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.mukesh.OnOtpCompletionListener;
import com.mukesh.OtpView;

import java.util.concurrent.TimeUnit;

public class SMSConfg extends AppCompatActivity {
    private OtpView otpView;
    private Button OnayBtn;
    private ActivitySmsconfgBinding binding; //bağlama
    private PhoneAuthProvider.ForceResendingToken forceResendingToken; //tekrar kod göndermek için
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String mVerificationId; //Doğruluma kodunu tutar.
    private static final String TAG = "Main_TAG";
    private FirebaseAuth firebaseAuth;
    private ProgressDialog pd;
    private String PhoneNumber = SMSGiris.UserPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        binding = ActivitySmsconfgBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.PhoneLl.setVisibility(View.VISIBLE); //telefon layout gösterir.
        binding.otpView.setVisibility(View.VISIBLE);   //code layout gösterir.
        firebaseAuth = FirebaseAuth.getInstance();
        pd = new ProgressDialog(SMSConfg.this);
        pd.setTitle("Lütfen Bekleyiniz...");
        pd.setCanceledOnTouchOutside(false);
        OnayBtn = (Button) findViewById(R.id.OnayBtn);
        otpView = findViewById(R.id.otp_view);
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                signInWithPhoneAuthCredential(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                pd.dismiss();
                Toast.makeText(SMSConfg.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken token) {
                super.onCodeSent(verificationId, token);
                Log.d(TAG, "Kod Gönderildi" + verificationId);
                mVerificationId = verificationId;
                forceResendingToken = token;
                pd.dismiss();
                Toast.makeText(SMSConfg.this, "Doğrulama Kodu Gönderildi", Toast.LENGTH_SHORT).show();
            }
        };
        startPhoneNumberVerification(PhoneNumber);

        binding.RepeatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resendVerificationCode(PhoneNumber, forceResendingToken);
            }
        });

        binding.OnayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = binding.otpView.getText().toString().trim();
                if (TextUtils.isEmpty(code)) {
                    Toast.makeText(SMSConfg.this, "Doğrulama kodunu giriniz...", Toast.LENGTH_SHORT).show();
                } else {
                    VerifyPhoneNumberWithCode(mVerificationId, code);
                }
            }
        });
    }

    private void startPhoneNumberVerification(String phone) {
        pd.setMessage("Numara Doğrulanıyor");
        pd.show();
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(firebaseAuth)
                        .setPhoneNumber(phone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void resendVerificationCode(String phone, PhoneAuthProvider.ForceResendingToken token) {
        pd.setMessage("Yeniden kod gönderiliyor");
        pd.show();
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(firebaseAuth)
                        .setPhoneNumber(phone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .setForceResendingToken(token)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private void VerifyPhoneNumberWithCode(String mVerificationId, String code) {
        pd.setMessage("Doğrulanıyor Kod.");
        pd.show();
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        pd.setMessage("Giriliyor");
        firebaseAuth.signInWithCredential(credential)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        pd.dismiss();

                        String phone = firebaseAuth.getCurrentUser().getPhoneNumber(); // Kullanıcı İsim-Soyisim olabilir.
                        Toast.makeText(SMSConfg.this, "Giriş Yapıldı" + phone, Toast.LENGTH_SHORT).show();
                        CallNextPage();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(SMSConfg.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void CallNextPage() {
        Intent odemeyapma = new Intent(SMSConfg.this, OdemeYapma.class);
        startActivity(odemeyapma);
    }

}