package com.example.gazipasa_municipality;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HalkMasa extends AppCompatActivity {
    private TextView FormText, Name_SurnameText, PhoneText, EmailText, SuggestText;
    private EditText Name_SurnameTextPlain, PhoneTextPlain, EmailTextPlain, SuggestTextPlain;
    private Button Gonder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_halk_masa);
        FormText = (TextView) findViewById(R.id.FormText);
        FormText.setText("  Mavi Masa\nBaşvuru Formu");
        Name_SurnameText = (TextView) findViewById(R.id.Name_SurnameText);
        Name_SurnameText.setText("Ad Soyad:");
        PhoneText = (TextView) findViewById(R.id.PhoneText);
        PhoneText.setText("Telefon:");
        EmailText = (TextView) findViewById(R.id.EmailText);
        EmailText.setText("Email:");
        SuggestText = (TextView) findViewById(R.id.SuggestText);
        SuggestText.setText("Öneri / Şikayet");
        Name_SurnameTextPlain = (EditText) findViewById(R.id.Name_SurnameTextPlain);
        PhoneTextPlain = (EditText) findViewById(R.id.PhoneTextPlain);
        EmailTextPlain = (EditText) findViewById(R.id.EmailTextPlain);
        SuggestTextPlain = (EditText) findViewById(R.id.EmailTextPlain);
        Gonder = (Button) findViewById(R.id.SendBtn);
        Gonder.setText("Gönder");

    }


}