package com.example.gazipasa_municipality;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class HalkMasa2 extends AppCompatActivity {
  private Button CepNoBtn,KurumNoBtn;
   public String CepNo="02425721013";
   public String KurumNo="120";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_halk_masa2);
        CepNoBtn=(Button)findViewById(R.id.CepNoBtn);
        KurumNoBtn=(Button)findViewById(R.id.KurumNoBtn);
        CepNoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Ceptel=CepNo.toString();
                Intent callıntent = new Intent(Intent.ACTION_DIAL);
                callıntent.setData(Uri.parse("tel:"+Ceptel));
                startActivity(callıntent);
            }
        });
         KurumNoBtn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String Kurumtel=KurumNo.toString();
                 Intent callıntent = new Intent((Intent.ACTION_DIAL));
                 callıntent.setData(Uri.parse("tel:"+Kurumtel));
                 startActivity(callıntent);
             }
         });


    }


}