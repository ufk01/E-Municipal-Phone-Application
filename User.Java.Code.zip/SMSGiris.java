package com.example.gazipasa_municipality;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class SMSGiris extends AppCompatActivity {
    private EditText UserInfo;
    private Button Girisbtn;
    private Connection connect;
    public static String UserPhoneNumber;
    private String PhoneNumber="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_smsgiris);
        UserInfo = (EditText) findViewById(R.id.UserInfo);
        Girisbtn = (Button) findViewById(R.id.Girisbtn);
        Girisbtn.setText("Giriş");
    }

    public void getSqlTxt(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(SMSGiris.this);
        String id = UserInfo.getText().toString();
        int counter = 0;
        if (id.isEmpty()) {
            builder.setTitle("Boş işlem yapılamaz");
            builder.setPositiveButton("Kapat", (DialogInterface.OnClickListener) (dialog, which) -> {
                dialog.cancel();
            });
            builder.show();
            finish();
        } else {
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                connect = connectionHelper.SMSGirisconnectionclass();
                if (connect != null) {
                    String query = "select \"TC_Kimlik\",\"Sicil_No\",\"Vergi_No\",\"Telefon_Numarası\" from Sheet1$ ";
                    Statement st = connect.createStatement();
                    ResultSet rs = st.executeQuery(query);
                    while (rs.next()) {
                        if (rs.getString(1).trim().equals(id.trim()) || rs.getString(2).trim().equals(id.trim()) || rs.getString(3).trim().equals(id.trim())) {
                           PhoneNumber=rs.getString(4).trim().toString();
                           UserPhoneNumber=PhoneNumber;
                            CallOdemeYapma();
                            counter++;
                            break;
                        }
                    }
                    if (counter == 0) {
                        builder.setTitle("Girdiğiniz Bilgiyi kontrol ediniz.");
                        builder.setPositiveButton("Kapat", (DialogInterface.OnClickListener) (dialog, which) -> {
                            dialog.cancel();
                        });
                        builder.show();
                        UserInfo.setText("");
                    }
                }
            } catch (Exception e) {
                Log.e("Sistemde sorun var!", e.getMessage());
            }
        }
    }

    public void CallOdemeYapma() {
        Intent odemeyapma = new Intent(SMSGiris.this, SMSConfg.class);
        startActivity(odemeyapma);
    }

}