package com.example.gazipasa_municipality;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.StrictMode;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionHelper  {
    Connection con;
    private String uname, pass, ip, port, database, driver;

    @SuppressLint("NewApi")
    public Connection UygeGirisconnectionclass() {
        ip = "10.0.2.2:53019";
        database = "UserData";
        uname = "GzpAdmin";
        pass = "m#P52s@ap$V";
        driver = "net.sourceforge.jtds.jdbc.Driver";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = null;
        try {
            Class.forName(driver);
            ConnectionURL = "jdbc:jtds:sqlserver://" + ip + ";databaseName=" + database + ";user=" + uname + ";password=" + pass + ";";
            System.out.println(ConnectionURL);
            connection = DriverManager.getConnection(ConnectionURL);
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        return connection;
    }

    public Connection SMSGirisconnectionclass() {
        ip = "10.0.2.2:53019";
        database = "SMS_GirisDataBase";
        uname = "GzpAdmin";
        pass = "m#P52s@ap$V";
        driver = "net.sourceforge.jtds.jdbc.Driver";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = null;
        try {
            Class.forName(driver);
            ConnectionURL = "jdbc:jtds:sqlserver://" + ip + ";databaseName=" + database + ";user=" + uname + ";password=" + pass + ";";
            System.out.println(ConnectionURL);
            connection = DriverManager.getConnection(ConnectionURL);
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        return connection;
    }


}
