package com.example.gzp_admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class SendMessage extends AppCompatActivity {
  EditText baslık,mesaj;
  Button gonder;
  private NotificationHelper mNotificationHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_send_message);
        baslık = (EditText) findViewById(R.id.Tittle);
        mesaj=(EditText)findViewById(R.id.Mesaj);
        gonder=(Button)findViewById(R.id.MesajGonder);
        mNotificationHelper = new NotificationHelper(this);

        gonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            sendOnChannel1(baslık.getText().toString(),mesaj.getText().toString());
            }
        });

    }
    public void sendOnChannel1(String tittle, String message){
        NotificationCompat.Builder nb = mNotificationHelper.getChannel1Notification(tittle,message);
        mNotificationHelper.getManager().notify(1, nb.build());
    }
}
