package com.example.gzp_admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity_admin extends AppCompatActivity {
EditText KullanıcıAdı;
TextInputEditText Sifre;
Button giris;
private final String kullanıcıAdı="Admin123";
private final String sifre="12345";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main_admin);
        KullanıcıAdı=(EditText)findViewById(R.id.KulanıcıGirisi);
        Sifre=(TextInputEditText)findViewById(R.id.Sifre);
        giris=(Button)findViewById(R.id.Giris2);



    }
    public void OnClick1(View v){
        if(KullanıcıAdı.getText().toString().equals(kullanıcıAdı) && Sifre.getText().toString().equals(sifre)){
            Intent kullanıcıpaneli= new Intent(MainActivity_admin.this,SendMessage.class);
            startActivity(kullanıcıpaneli);
        }
        else{
            System.out.println(KullanıcıAdı.getText().toString());
            System.out.println(Sifre.getText().toString());
            Toast.makeText(this, "Yanlış girdiniz", Toast.LENGTH_SHORT).show();
        }
    }
}